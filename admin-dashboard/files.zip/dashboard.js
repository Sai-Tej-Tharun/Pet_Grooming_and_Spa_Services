/**
 * PawSpa — dashboard.js
 * Full admin dashboard logic:
 * 01. Theme toggle
 * 02. Sidebar navigation + mobile
 * 03. Notification system (fully functional)
 * 04. SVG Revenue chart
 * 05. Donut chart
 * 06. Bookings table (overview + full)
 * 07. Customers grid
 * 08. Services management
 * 09. Revenue transactions
 * 10. Pet profiles
 * 11. Reviews
 * 12. Blog CMS
 * 13. Messages
 * 14. KPI counter animations
 * 15. Breed bars
 * 16. Activity feed
 * 17. Groomer leaderboard
 * 18. Toast notifications
 * 19. Entry point
 */

'use strict';

/* ═══════════════════════════════════════════
   DATA STORE
   ══════════════════════════════════════════ */
const DATA = {

  notifications: [
    { id:1,  type:'booking',  title:'New Booking — Bruno (Golden Retriever)', desc:'Priya Sharma booked Full Grooming for 2:00 PM today.', time:'2 min ago', unread:true },
    { id:2,  type:'booking',  title:'Booking Confirmed — Max (Labrador)',      desc:'Rahul Nair\'s appointment confirmed for tomorrow 10 AM.',  time:'15 min ago', unread:true },
    { id:3,  type:'review',   title:'New 5★ Review — Kavya Reddy',            desc:'"Princess loved her spa day! Absolutely magical experience."', time:'32 min ago', unread:true },
    { id:4,  type:'cancel',   title:'Booking Cancelled — Mochi (Shih Tzu)',   desc:'Nisha Kapoor cancelled her 11 AM appointment.',  time:'1 hr ago', unread:true },
    { id:5,  type:'message',  title:'New Message — Arjun Mehta',              desc:'"Hi, I wanted to ask about the medicated bath option for my cat."', time:'2 hrs ago', unread:true },
    { id:6,  type:'booking',  title:'New Booking — Luna (Persian Cat)',        desc:'Sneha Iyer booked Bath & Blow Dry for Saturday.',  time:'3 hrs ago', unread:false },
    { id:7,  type:'review',   title:'New Review Needs Moderation',            desc:'A 3-star review is awaiting your approval before publishing.', time:'4 hrs ago', unread:true },
    { id:8,  type:'system',   title:'System: Weekly Report Ready',            desc:'Your revenue report for the week ending 29 Mar is ready.', time:'6 hrs ago', unread:true },
    { id:9,  type:'message',  title:'New Message — Fatima Sheikh',            desc:'"Can we reschedule Pearl\'s session to next week?"', time:'8 hrs ago', unread:false },
    { id:10, type:'system',   title:'System: Backup Completed',              desc:'Daily data backup completed successfully at 03:00 AM.', time:'Yesterday', unread:false },
  ],

  bookings: [
    { id:'#B001', customer:'Priya Sharma',   pet:'Bruno (Golden Retriever)', service:'Full Grooming',   time:'09:00 AM', groomer:'Ananya K.', status:'confirmed',  amount:'₹1,799' },
    { id:'#B002', customer:'Rahul Nair',     pet:'Max (Labrador)',           service:'Bath & Blow Dry', time:'10:00 AM', groomer:'Riya M.',   status:'confirmed',  amount:'₹999'   },
    { id:'#B003', customer:'Sneha Iyer',     pet:'Luna (Persian Cat)',       service:'Hair Styling',    time:'11:00 AM', groomer:'Kiran D.',  status:'confirmed',  amount:'₹799'   },
    { id:'#B004', customer:'Arjun Mehta',    pet:'Cloud (Maltese)',          service:'Luxury Spa',      time:'12:00 PM', groomer:'Ananya K.', status:'pending',    amount:'₹2,199' },
    { id:'#B005', customer:'Kavya Reddy',    pet:'Princess (Poodle)',        service:'Full Grooming',   time:'01:00 PM', groomer:'Kiran D.',  status:'confirmed',  amount:'₹1,299' },
    { id:'#B006', customer:'Vikram Joshi',   pet:'Sandy (Golden Retriever)', service:'Bath & Blow Dry', time:'02:00 PM', groomer:'Riya M.',   status:'completed',  amount:'₹999'   },
    { id:'#B007', customer:'Nisha Kapoor',   pet:'Mochi (Shih Tzu)',         service:'Nail Clipping',   time:'03:00 PM', groomer:'Sunita V.', status:'cancelled',  amount:'₹249'   },
    { id:'#B008', customer:'Fatima Sheikh',  pet:'Pearl (Persian Cat)',      service:'Ear Cleaning',    time:'04:00 PM', groomer:'Priya N.',  status:'confirmed',  amount:'₹299'   },
  ],

  customers: [
    { name:'Priya Sharma',  email:'priya@email.com',  avatar:'https://i.pravatar.cc/80?img=11', sessions:8, spent:'₹12,400', pet:'Bruno 🐕', loyalty:'Gold' },
    { name:'Rahul Nair',    email:'rahul@email.com',  avatar:'https://i.pravatar.cc/80?img=32', sessions:6, spent:'₹8,200',  pet:'Max 🐕',   loyalty:'Silver' },
    { name:'Sneha Iyer',    email:'sneha@email.com',  avatar:'https://i.pravatar.cc/80?img=45', sessions:5, spent:'₹6,100',  pet:'Luna 🐱',  loyalty:'Silver' },
    { name:'Kavya Reddy',   email:'kavya@email.com',  avatar:'https://i.pravatar.cc/80?img=23', sessions:10,spent:'₹19,800', pet:'Princess 🐩', loyalty:'Gold' },
    { name:'Arjun Mehta',   email:'arjun@email.com',  avatar:'https://i.pravatar.cc/80?img=47', sessions:4, spent:'₹4,200',  pet:'Cloud 🐱',  loyalty:'Bronze' },
    { name:'Vikram Joshi',  email:'vikram@email.com', avatar:'https://i.pravatar.cc/80?img=41', sessions:7, spent:'₹9,300',  pet:'Sandy 🐕', loyalty:'Gold' },
  ],

  services: [
    { name:'Full Grooming Package', price:'from ₹1,299', sessions:128, img:'https://images.unsplash.com/photo-1516734212186-a967f81ad0d7?w=400&h=200&fit=crop&q=70', status:'published' },
    { name:'Bath & Blow Dry',       price:'from ₹499',   sessions:98,  img:'https://images.unsplash.com/photo-1585664811087-47f65abbad64?w=400&h=200&fit=crop&q=70',  status:'published' },
    { name:'Hair Styling',          price:'from ₹799',   sessions:67,  img:'https://images.unsplash.com/photo-1537151608828-ea2b11777ee8?w=400&h=200&fit=crop&q=70', status:'published' },
    { name:'Nail Clipping',         price:'₹249 flat',   sessions:145, img:'https://images.unsplash.com/photo-1601758124510-52d02ddb7cbd?w=400&h=200&fit=crop&q=70', status:'published' },
    { name:'Ear Cleaning',          price:'₹299 flat',   sessions:89,  img:'https://images.unsplash.com/photo-1625316708582-7c38734be31d?w=400&h=200&fit=crop&q=70', status:'published' },
    { name:'Luxury Spa Treatment',  price:'from ₹2,199', sessions:34,  img:'https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=400&h=200&fit=crop&q=70',   status:'published' },
  ],

  revenueTransactions: [
    { date:'01 Apr 2026', customer:'Kavya Reddy',   service:'Luxury Spa',      amount:'₹2,199', payment:'UPI',   status:'paid' },
    { date:'01 Apr 2026', customer:'Priya Sharma',  service:'Full Grooming',   amount:'₹1,799', payment:'Card',  status:'paid' },
    { date:'01 Apr 2026', customer:'Rahul Nair',    service:'Bath & Blow Dry', amount:'₹999',   payment:'Cash',  status:'paid' },
    { date:'31 Mar 2026', customer:'Sneha Iyer',    service:'Hair Styling',    amount:'₹799',   payment:'UPI',   status:'paid' },
    { date:'31 Mar 2026', customer:'Nisha Kapoor',  service:'Full Grooming',   amount:'₹1,299', payment:'Card',  status:'refunded' },
    { date:'30 Mar 2026', customer:'Vikram Joshi',  service:'Bath & Blow Dry', amount:'₹999',   payment:'UPI',   status:'paid' },
  ],

  pets: [
    { name:'Bruno',    breed:'Golden Retriever', owner:'Priya Sharma',  emoji:'🐕', visits:8  },
    { name:'Max',      breed:'Labrador',          owner:'Rahul Nair',    emoji:'🐕', visits:6  },
    { name:'Luna',     breed:'Persian Cat',       owner:'Sneha Iyer',    emoji:'🐱', visits:5  },
    { name:'Princess', breed:'Standard Poodle',   owner:'Kavya Reddy',   emoji:'🐩', visits:10 },
    { name:'Cloud',    breed:'Maltese',            owner:'Arjun Mehta',   emoji:'🐱', visits:4  },
    { name:'Sandy',    breed:'Golden Retriever',  owner:'Vikram Joshi',  emoji:'🐕', visits:7  },
    { name:'Oreo',     breed:'Beagle',            owner:'Dev Anand',     emoji:'🐕', visits:3  },
    { name:'Pearl',    breed:'Persian Cat',       owner:'Fatima Sheikh', emoji:'🐱', visits:5  },
  ],

  reviews: [
    { author:'Priya Sharma',  service:'Full Grooming', rating:5, text:'"Bruno looks like a show dog every time — the groomers nail his breed cut perfectly."',  date:'2 Apr 2026', status:'published', avatar:'https://i.pravatar.cc/60?img=11' },
    { author:'Kavya Reddy',   service:'Luxury Spa',    rating:5, text:'"Princess came home smelling of lavender and absolutely glowing. Best decision ever!"',   date:'1 Apr 2026', status:'published', avatar:'https://i.pravatar.cc/60?img=23' },
    { author:'Rahul Nair',    service:'Bath & Blow Dry',rating:5,text:'"Max actually gets excited on the way there now — that says everything about PawSpa!"',  date:'31 Mar 2026',status:'published', avatar:'https://i.pravatar.cc/60?img=32' },
    { author:'Sneha Iyer',    service:'Hair Styling',  rating:5, text:'"The groomer took 15 extra minutes to work through Luna\'s tangles without charging extra."', date:'30 Mar 2026',status:'pending-review', avatar:'https://i.pravatar.cc/60?img=45' },
    { author:'Arjun Mehta',   service:'Ear Cleaning',  rating:4, text:'"Very professional and gentle with my anxious cat. Only minor wait time."',              date:'29 Mar 2026',status:'published', avatar:'https://i.pravatar.cc/60?img=47' },
    { author:'Vikram Joshi',  service:'Full Grooming', rating:5, text:'"Sandy has sensitive skin and PawSpa used the hypoallergenic shampoo — zero reaction!"', date:'28 Mar 2026',status:'hidden',    avatar:'https://i.pravatar.cc/60?img=41' },
  ],

  blogPosts: [
    { title:'10 Signs Your Dog Needs a Grooming Session', cat:'Grooming Tips', date:'01 Apr 2026', views:1240, status:'published', img:'https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=400&h=180&fit=crop&q=70' },
    { title:'How Often Should You Bathe Your Cat?',       cat:'Pet Health',    date:'28 Mar 2026', views:980,  status:'published', img:'https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=400&h=180&fit=crop&q=70' },
    { title:'Choosing the Right Shampoo for Your Pet',    cat:'Grooming Tips', date:'25 Mar 2026', views:752,  status:'published', img:'https://images.unsplash.com/photo-1585664811087-47f65abbad64?w=400&h=180&fit=crop&q=70' },
    { title:'Understanding Your Dog\'s Coat Type',        cat:'Breed Guides',  date:'20 Mar 2026', views:2100, status:'published', img:'https://images.unsplash.com/photo-1516734212186-a967f81ad0d7?w=400&h=180&fit=crop&q=70' },
    { title:'Benefits of Regular Nail Trimming',          cat:'Pet Health',    date:'—',           views:0,    status:'draft',     img:'https://images.unsplash.com/photo-1601758124510-52d02ddb7cbd?w=400&h=180&fit=crop&q=70' },
    { title:'PawSpa Spring Grooming Guide 2026',          cat:'Grooming Tips', date:'05 Apr 2026', views:0,    status:'scheduled', img:'https://images.unsplash.com/photo-1537151608828-ea2b11777ee8?w=400&h=180&fit=crop&q=70' },
  ],

  messages: [
    { id:1, name:'Arjun Mehta',   avatar:'https://i.pravatar.cc/60?img=47', preview:'Hi, I wanted to ask about the medicated bath...', time:'2 hrs ago', unread:true  },
    { id:2, name:'Fatima Sheikh', avatar:'https://i.pravatar.cc/60?img=29', preview:'Can we reschedule Pearl\'s session to next week?',time:'8 hrs ago', unread:true  },
    { id:3, name:'Dev Anand',     avatar:'https://i.pravatar.cc/60?img=18', preview:'Does PawSpa accept walk-in appointments?',        time:'Yesterday', unread:true  },
    { id:4, name:'Priya Sharma',  avatar:'https://i.pravatar.cc/60?img=11', preview:'Thank you so much! Bruno looks amazing.',          time:'2 days ago',unread:false },
    { id:5, name:'Rahul Nair',    avatar:'https://i.pravatar.cc/60?img=32', preview:'What products do you use for sensitive skin?',     time:'3 days ago',unread:false },
  ],

  groomers: [
    { name:'Ananya Krishnan', avatar:'https://i.pravatar.cc/60?img=25', role:'Lead Groomer',  sessions:48, rating:'4.98' },
    { name:'Kiran Das',       avatar:'https://i.pravatar.cc/60?img=33', role:'Master Stylist', sessions:42, rating:'4.97' },
    { name:'Riya Menon',      avatar:'https://i.pravatar.cc/60?img=47', role:'Bath Specialist',sessions:38, rating:'4.95' },
    { name:'Sunita Verma',    avatar:'https://i.pravatar.cc/60?img=60', role:'Nail Specialist',sessions:35, rating:'4.99' },
    { name:'Priya Nambiar',   avatar:'https://i.pravatar.cc/60?img=16', role:'Ear Specialist', sessions:29, rating:'4.96' },
  ],

  activityFeed: [
    { icon:'booking', color:'green', text:'<strong>Priya Sharma</strong> booked Full Grooming for Bruno — ₹1,799', time:'2 min ago' },
    { icon:'review',  color:'gold',  text:'<strong>Kavya Reddy</strong> left a 5★ review for Luxury Spa', time:'32 min ago' },
    { icon:'cancel',  color:'red',   text:'<strong>Nisha Kapoor</strong> cancelled her 11 AM appointment', time:'1 hr ago' },
    { icon:'message', color:'aqua',  text:'New message from <strong>Arjun Mehta</strong> about medicated bath', time:'2 hrs ago' },
    { icon:'booking', color:'green', text:'<strong>Vikram Joshi</strong> completed Bath & Blow Dry — ₹999', time:'3 hrs ago' },
    { icon:'review',  color:'gold',  text:'New 3★ review is awaiting moderation approval', time:'4 hrs ago' },
    { icon:'lav',     color:'lav',   text:'System: Weekly revenue report is ready for review', time:'6 hrs ago' },
  ],

  breedBreakdown: [
    { breed:'Golden Retriever', count:68, pct:85 },
    { breed:'Labrador',         count:54, pct:68 },
    { breed:'Poodle',           count:47, pct:59 },
    { breed:'Persian Cat',      count:39, pct:49 },
    { breed:'Shih Tzu',         count:34, pct:43 },
    { breed:'Beagle',           count:28, pct:35 },
  ],

  donutData: [
    { label:'Full Grooming', value:128, color:'#3E7C59' },
    { label:'Bath & Blow',   value:98,  color:'#7ED1C6' },
    { label:'Nail Clipping', value:67,  color:'#D9A85F' },
    { label:'Luxury Spa',    value:34,  color:'#C7B8EA' },
    { label:'Others',        value:15,  color:'#F2B8A0' },
  ],

  revenueWeek: [28400, 31200, 26800, 35600, 38420, 29000, 42100],

};

/* ═══════════════════════════════════════════
   01. THEME TOGGLE
   ══════════════════════════════════════════ */
function initTheme () {
  const btn   = document.getElementById('dash-theme');
  const light = btn?.querySelector('[data-icon-light]');
  const dark  = btn?.querySelector('[data-icon-dark]');
  let   theme = localStorage.getItem('pawspa-theme') || 'light';

  const apply = t => {
    document.documentElement.setAttribute('data-theme', t);
    localStorage.setItem('pawspa-theme', t);
    theme = t;
    if (light) light.style.display = t === 'dark'  ? 'block' : 'none';
    if (dark)  dark.style.display  = t === 'light' ? 'block' : 'none';
  };
  apply(theme);
  btn?.addEventListener('click', () => apply(theme === 'dark' ? 'light' : 'dark'));
}

/* ═══════════════════════════════════════════
   02. SIDEBAR NAVIGATION
   ══════════════════════════════════════════ */
function initNav () {
  const sidebar  = document.getElementById('sidebar');
  const hamBtn   = document.getElementById('ham-btn');
  const overlay  = document.getElementById('sb-overlay');
  const links    = document.querySelectorAll('.sb-link[data-section]');
  const sections = document.querySelectorAll('.dash-section');

  // Switch section
  links.forEach(link => {
    link.addEventListener('click', e => {
      e.preventDefault();
      const sec = link.dataset.section;

      links.forEach(l => l.classList.remove('active'));
      link.classList.add('active');
      link.setAttribute('aria-current', 'page');

      sections.forEach(s => s.classList.remove('active'));
      document.getElementById(`sec-${sec}`)?.classList.add('active');

      // Close mobile sidebar
      if (window.innerWidth <= 900) closeSidebar();
    });
  });

  // Mobile toggle
  function openSidebar () {
    sidebar.classList.add('open');
    overlay.classList.add('open');
    hamBtn?.setAttribute('aria-expanded', 'true');
  }
  function closeSidebar () {
    sidebar.classList.remove('open');
    overlay.classList.remove('open');
    hamBtn?.setAttribute('aria-expanded', 'false');
  }

  hamBtn?.addEventListener('click', () => {
    sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
  });
  overlay?.addEventListener('click', closeSidebar);
}

/* ═══════════════════════════════════════════
   03. NOTIFICATION SYSTEM
   ══════════════════════════════════════════ */
function initNotifications () {
  const btn       = document.getElementById('notif-btn');
  const dropdown  = document.getElementById('notif-dropdown');
  const closeBtn  = document.getElementById('notif-close');
  const markAllBtn= document.getElementById('mark-all-read');
  const countBadge= document.getElementById('notif-count');
  const dot       = document.getElementById('notif-dot');
  const tabs      = document.querySelectorAll('.notif-tab');
  const listEl    = document.getElementById('notif-list');

  if (!btn || !dropdown) return;

  let notifications = [...DATA.notifications];
  let currentTab    = 'all';
  let isOpen        = false;

  /* ── Helpers ── */
  const unreadCount = () => notifications.filter(n => n.unread).length;

  const typeToTab = { booking:'bookings', review:'reviews', system:'system', cancel:'bookings', message:'all' };

  const iconMap = {
    booking: { cls:'notif-icon--booking', svg:'<path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>' },
    review:  { cls:'notif-icon--review',  svg:'<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>' },
    message: { cls:'notif-icon--message', svg:'<path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/>' },
    system:  { cls:'notif-icon--system',  svg:'<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>' },
    cancel:  { cls:'notif-icon--cancel',  svg:'<circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/>' },
  };

  /* ── Render ── */
  const renderList = () => {
    const filtered = currentTab === 'all'
      ? notifications
      : notifications.filter(n => (typeToTab[n.type] || 'all') === currentTab);

    if (!filtered.length) {
      listEl.innerHTML = '<div class="notif-empty">🐾 No notifications here</div>';
      return;
    }

    listEl.innerHTML = filtered.map(n => {
      const ic = iconMap[n.type] || iconMap.system;
      return `
        <div class="notif-item ${n.unread ? 'unread' : ''}" data-id="${n.id}" role="listitem">
          <div class="notif-icon ${ic.cls}">
            <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">${ic.svg}</svg>
          </div>
          <div class="notif-item__body">
            <p class="notif-item__title">${n.title}</p>
            <p class="notif-item__desc">${n.desc}</p>
            <p class="notif-item__time">${n.time}</p>
          </div>
          <button class="notif-item__del" data-del="${n.id}" aria-label="Dismiss notification">✕</button>
        </div>
      `;
    }).join('');

    // Click on item = mark as read
    listEl.querySelectorAll('.notif-item').forEach(item => {
      item.addEventListener('click', e => {
        if (e.target.closest('[data-del]')) return; // handled by delete button
        const id = +item.dataset.id;
        const notif = notifications.find(n => n.id === id);
        if (notif && notif.unread) {
          notif.unread = false;
          updateBadge();
          renderList();
          showToast(`Notification marked as read`, 'info');
        }
      });
    });

    // Delete button
    listEl.querySelectorAll('[data-del]').forEach(del => {
      del.addEventListener('click', e => {
        e.stopPropagation();
        const id = +del.dataset.del;
        notifications = notifications.filter(n => n.id !== id);
        updateBadge();
        updateTabCounts();
        renderList();
      });
    });
  };

  const updateBadge = () => {
    const cnt = unreadCount();
    countBadge.textContent = cnt;
    countBadge.classList.toggle('hidden', cnt === 0);
    dot.style.display = cnt > 0 ? 'block' : 'none';
  };

  const updateTabCounts = () => {
    tabs.forEach(tab => {
      const tabKey = tab.dataset.tab;
      let count;
      if (tabKey === 'all') {
        count = notifications.length;
      } else {
        count = notifications.filter(n => (typeToTab[n.type] || 'all') === tabKey).length;
      }
      const cntEl = tab.querySelector('.ntab-cnt');
      if (cntEl) cntEl.textContent = count;
    });
  };

  /* ── Open / Close ── */
  const open  = () => { isOpen = true;  dropdown.classList.add('open');    btn.setAttribute('aria-expanded', 'true');  };
  const close = () => { isOpen = false; dropdown.classList.remove('open'); btn.setAttribute('aria-expanded', 'false'); };

  btn.addEventListener('click', e => {
    e.stopPropagation();
    isOpen ? close() : open();
  });

  closeBtn?.addEventListener('click', close);

  // Close on outside click
  document.addEventListener('click', e => {
    if (isOpen && !document.getElementById('notif-wrap')?.contains(e.target)) close();
  });

  // ESC key
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && isOpen) close(); });

  /* ── Tabs ── */
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => { t.classList.remove('active'); t.setAttribute('aria-selected', 'false'); });
      tab.classList.add('active');
      tab.setAttribute('aria-selected', 'true');
      currentTab = tab.dataset.tab;
      renderList();
    });
  });

  /* ── Mark All Read ── */
  markAllBtn?.addEventListener('click', () => {
    notifications.forEach(n => n.unread = false);
    updateBadge();
    renderList();
    showToast('All notifications marked as read 🐾', 'success');
  });

  /* ── Simulate live notifications (demo) ── */
  let liveCount = 0;
  const liveNotifs = [
    { id:100, type:'booking', title:'New Booking — Rocky (Labrador)',     desc:'Suresh Kumar just booked Nail Clipping for 5 PM.', time:'just now', unread:true },
    { id:101, type:'review',  title:'New 5★ Review just submitted',       desc:'"Absolutely amazing service — will be back every month!"', time:'just now', unread:true },
    { id:102, type:'message', title:'New Message — Lakshmi Rajan',        desc:'"Do you have availability this weekend for my rabbit?"', time:'just now', unread:true },
  ];

  const liveTick = () => {
    if (liveCount >= liveNotifs.length) return;
    const notif = liveNotifs[liveCount++];
    notifications.unshift(notif);
    updateBadge();
    updateTabCounts();
    if (isOpen) renderList();
    // Show mini toast for live notification
    showToast(`🔔 ${notif.title}`, 'info');
  };

  // Stagger live notifications at 15s, 35s, 60s
  setTimeout(liveTick, 15000);
  setTimeout(liveTick, 35000);
  setTimeout(liveTick, 60000);

  /* ── Initial render ── */
  updateBadge();
  updateTabCounts();
  renderList();
}

/* ═══════════════════════════════════════════
   04. SVG REVENUE CHART
   ══════════════════════════════════════════ */
function renderRevenueChart () {
  const container = document.getElementById('revenue-chart');
  if (!container) return;

  const data   = DATA.revenueWeek;
  const days   = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
  const W      = 600;
  const H      = 160;
  const padL   = 50;
  const padR   = 20;
  const padT   = 20;
  const padB   = 30;
  const chartW = W - padL - padR;
  const chartH = H - padT - padB;
  const max    = Math.max(...data) * 1.1;
  const min    = Math.min(...data) * 0.85;

  const xPos = i => padL + (i / (data.length - 1)) * chartW;
  const yPos = v => padT + chartH - ((v - min) / (max - min)) * chartH;

  // Build path
  const linePath  = data.map((v, i) => `${i === 0 ? 'M' : 'L'}${xPos(i).toFixed(1)},${yPos(v).toFixed(1)}`).join(' ');
  const areaPath  = `${linePath} L${xPos(data.length-1).toFixed(1)},${(padT+chartH).toFixed(1)} L${padL},${(padT+chartH).toFixed(1)} Z`;

  // Y-axis labels
  const yLabels = [0,1,2,3].map(i => {
    const v = min + (max - min) * (i/3);
    return `<text x="${padL - 6}" y="${(padT + chartH - (i/3)*chartH + 4).toFixed(1)}" text-anchor="end" class="chart-label">₹${(v/1000).toFixed(0)}K</text>`;
  }).join('');

  // Gridlines
  const gridLines = [0,1,2,3].map(i => {
    const y = (padT + chartH - (i/3)*chartH).toFixed(1);
    return `<line x1="${padL}" y1="${y}" x2="${padL+chartW}" y2="${y}" class="chart-grid"/>`;
  }).join('');

  // X-axis labels + data points
  const xLabels = days.map((d,i) => `<text x="${xPos(i).toFixed(1)}" y="${H-8}" text-anchor="middle" class="chart-label">${d}</text>`).join('');
  const dots    = data.map((v,i) => `<circle cx="${xPos(i).toFixed(1)}" cy="${yPos(v).toFixed(1)}" r="4" class="chart-dot" data-val="${v}"/>`).join('');

  const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
  const gridC  = isDark ? 'rgba(42,61,48,.5)' : 'rgba(230,232,236,.8)';
  const labelC = isDark ? '#8DA995' : '#6B7280';

  container.innerHTML = `
    <style>
      .chart-grid  { stroke: ${gridC}; stroke-width:1; stroke-dasharray:3,3; }
      .chart-label { font-family:'Poppins',sans-serif; font-size:9px; fill:${labelC}; }
      .chart-dot   { fill:#3E7C59; stroke:#fff; stroke-width:2; transition:r .2s; cursor:pointer; }
      .chart-dot:hover { r:6; }
      .chart-area-path { transition:d .5s; }
    </style>
    <svg viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <defs>
        <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"   stop-color="#3E7C59" stop-opacity=".25"/>
          <stop offset="100%" stop-color="#3E7C59" stop-opacity=".02"/>
        </linearGradient>
      </defs>
      ${gridLines}
      ${yLabels}
      ${xLabels}
      <path d="${areaPath}" fill="url(#areaGrad)" class="chart-area-path"/>
      <path d="${linePath}" fill="none" stroke="#3E7C59" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
      ${dots}
    </svg>
  `;
}

/* ═══════════════════════════════════════════
   05. DONUT CHART
   ══════════════════════════════════════════ */
function renderDonutChart () {
  const segmentsEl = document.getElementById('donut-segments');
  const legendEl   = document.getElementById('donut-legend');
  if (!segmentsEl || !legendEl) return;

  const data  = DATA.donutData;
  const total = data.reduce((a, d) => a + d.value, 0);
  const cx    = 60;
  const cy    = 60;
  const r     = 44;
  const inner = 28;

  let startAngle = -90;

  const polarToCart = (cx, cy, r, angle) => {
    const rad = (angle * Math.PI) / 180;
    return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) };
  };

  const segments = data.map(d => {
    const pct     = d.value / total;
    const sweep   = pct * 360;
    const end     = startAngle + sweep;
    const large   = sweep > 180 ? 1 : 0;

    const p1o = polarToCart(cx, cy, r, startAngle);
    const p2o = polarToCart(cx, cy, r, end);
    const p1i = polarToCart(cx, cy, inner, end);
    const p2i = polarToCart(cx, cy, inner, startAngle);

    const path = [
      `M ${p1o.x.toFixed(2)} ${p1o.y.toFixed(2)}`,
      `A ${r} ${r} 0 ${large} 1 ${p2o.x.toFixed(2)} ${p2o.y.toFixed(2)}`,
      `L ${p1i.x.toFixed(2)} ${p1i.y.toFixed(2)}`,
      `A ${inner} ${inner} 0 ${large} 0 ${p2i.x.toFixed(2)} ${p2i.y.toFixed(2)}`,
      'Z',
    ].join(' ');

    startAngle = end;
    return { ...d, path, pct: (pct * 100).toFixed(0) };
  });

  segmentsEl.innerHTML = segments.map((s, i) =>
    `<path d="${s.path}" fill="${s.color}" opacity=".9" style="transition:transform .2s;transform-origin:${cx}px ${cy}px;cursor:pointer"
      onmouseenter="this.style.transform='scale(1.05)'" onmouseleave="this.style.transform='scale(1)'"
      aria-label="${s.label}: ${s.value} sessions"/>`
  ).join('');

  legendEl.innerHTML = segments.map(s =>
    `<li class="dl-item">
       <span class="dl-dot" style="background:${s.color}"></span>
       <span>${s.label}</span>
       <span class="dl-pct">${s.pct}%</span>
     </li>`
  ).join('');
}

/* ═══════════════════════════════════════════
   06. BOOKINGS TABLE (overview)
   ══════════════════════════════════════════ */
function renderBookingsTable () {
  const tbody = document.getElementById('bookings-tbody');
  if (!tbody) return;

  const statusIcon = s => {
    const icons = { confirmed:'✓', pending:'⏳', completed:'✓✓', cancelled:'✕' };
    return icons[s] || '?';
  };

  tbody.innerHTML = DATA.bookings.map(b => `
    <tr>
      <td>
        <div style="display:flex;align-items:center;gap:.5rem">
          <div style="width:30px;height:30px;border-radius:50%;background:rgba(62,124,89,.1);display:flex;align-items:center;justify-content:center;font-size:.7rem;font-weight:700;color:var(--g);">${b.customer.charAt(0)}</div>
          <div>
            <div style="font-family:var(--fh);font-size:.8rem;font-weight:600;color:var(--head)">${b.customer}</div>
          </div>
        </div>
      </td>
      <td style="font-size:.78rem;color:var(--muted)">${b.pet}</td>
      <td style="font-family:var(--fh);font-size:.78rem;font-weight:500">${b.service}</td>
      <td style="font-family:var(--fh);font-size:.78rem;font-weight:600;color:var(--g)">${b.time}</td>
      <td style="font-size:.78rem">${b.groomer}</td>
      <td><span class="status-badge status--${b.status}">${b.status.charAt(0).toUpperCase() + b.status.slice(1)}</span></td>
      <td style="font-family:var(--fh);font-size:.82rem;font-weight:700;color:var(--head)">${b.amount}</td>
    </tr>
  `).join('');
}

/* ═══════════════════════════════════════════
   07. ALL BOOKINGS (bookings section)
   ══════════════════════════════════════════ */
function renderAllBookings () {
  const tbody = document.getElementById('all-bookings-tbody');
  if (!tbody) return;

  const allBookings = [...DATA.bookings, ...DATA.bookings].map((b, i) => ({
    ...b,
    id: `#B${String(i+1).padStart(3,'0')}`,
    date: ['01 Apr','01 Apr','02 Apr','02 Apr','03 Apr','03 Apr','04 Apr','04 Apr'][i % 8],
  }));

  tbody.innerHTML = allBookings.map(b => `
    <tr>
      <td style="font-family:var(--fh);font-size:.78rem;font-weight:600;color:var(--g)">${b.id}</td>
      <td style="font-size:.8rem;font-weight:600;color:var(--head)">${b.customer}</td>
      <td style="font-size:.75rem;color:var(--muted)">${b.pet}</td>
      <td style="font-size:.78rem">${b.service}</td>
      <td style="font-family:var(--fh);font-size:.75rem">${b.date} · ${b.time}</td>
      <td style="font-size:.75rem">${b.groomer}</td>
      <td style="font-family:var(--fh);font-size:.82rem;font-weight:700">${b.amount}</td>
      <td><span class="status-badge status--${b.status}">${b.status.charAt(0).toUpperCase() + b.status.slice(1)}</span></td>
      <td>
        <div class="tbl-actions">
          <button class="tbl-btn" aria-label="View booking" onclick="showToast('Opening booking details…','info')">
            <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
          </button>
          <button class="tbl-btn" aria-label="Edit booking" onclick="showToast('Opening edit form…','info')">
            <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
          </button>
          <button class="tbl-btn tbl-btn--del" aria-label="Cancel booking" onclick="showToast('Booking cancelled','error')">
            <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/></svg>
          </button>
        </div>
      </td>
    </tr>
  `).join('');
}

/* ═══════════════════════════════════════════
   08. CUSTOMERS GRID
   ══════════════════════════════════════════ */
function renderCustomers () {
  const grid = document.getElementById('customers-grid');
  if (!grid) return;

  const loyaltyColor = { Gold:'var(--gold)', Silver:'var(--muted)', Bronze:'#c27054' };

  grid.innerHTML = DATA.customers.map(c => `
    <div class="customer-card">
      <div class="cc-top">
        <img src="${c.avatar}" alt="${c.name}" class="cc-avatar" loading="lazy" />
        <div>
          <p class="cc-name">${c.name}</p>
          <p class="cc-email">${c.email}</p>
        </div>
        <span class="status-badge status--confirmed" style="margin-left:auto;font-size:.62rem;background:rgba(217,168,95,.12);color:${loyaltyColor[c.loyalty]}">${c.loyalty} 🏅</span>
      </div>
      <div class="cc-stats">
        <div class="cc-stat"><p class="cc-stat__val">${c.sessions}</p><p class="cc-stat__lbl">Sessions</p></div>
        <div class="cc-stat"><p class="cc-stat__val">${c.spent}</p><p class="cc-stat__lbl">Total Spent</p></div>
      </div>
      <div style="font-size:.75rem;color:var(--muted);margin-bottom:.75rem">Pet: <strong style="color:var(--head)">${c.pet}</strong></div>
      <div class="cc-actions">
        <button class="dash-btn dash-btn--sm dash-btn--outline" onclick="showToast('Opening profile…','info')">View Profile</button>
        <button class="dash-btn dash-btn--sm" onclick="showToast('Opening booking form…','success')">Book Now</button>
      </div>
    </div>
  `).join('');
}

/* ═══════════════════════════════════════════
   09. SERVICES MANAGEMENT
   ══════════════════════════════════════════ */
function renderServices () {
  const grid = document.getElementById('services-mgmt-grid');
  if (!grid) return;

  grid.innerHTML = DATA.services.map(s => `
    <div class="svc-mgmt-card">
      <img src="${s.img}" alt="${s.name}" class="svc-mgmt-card__img" loading="lazy" />
      <div class="svc-mgmt-card__body">
        <p class="svc-mgmt-card__name">${s.name}</p>
        <p class="svc-mgmt-card__price">${s.price}</p>
        <p style="font-size:.72rem;color:var(--muted)">${s.sessions} sessions this month</p>
        <div class="svc-mgmt-card__foot">
          <span class="status-badge status--${s.status}">${s.status.charAt(0).toUpperCase() + s.status.slice(1)}</span>
          <div style="display:flex;gap:.375rem">
            <button class="tbl-btn" aria-label="Edit" onclick="showToast('Opening service editor…','info')"><svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="12" height="12"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg></button>
            <button class="tbl-btn tbl-btn--del" aria-label="Delete" onclick="showToast('Confirm deletion?','error')"><svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="12" height="12"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/></svg></button>
          </div>
        </div>
      </div>
    </div>
  `).join('');
}

/* ═══════════════════════════════════════════
   10. REVENUE TRANSACTIONS
   ══════════════════════════════════════════ */
function renderRevenueTable () {
  const tbody = document.getElementById('revenue-tbody');
  if (!tbody) return;
  tbody.innerHTML = DATA.revenueTransactions.map(t => `
    <tr>
      <td style="font-size:.78rem">${t.date}</td>
      <td style="font-size:.8rem;font-weight:600;color:var(--head)">${t.customer}</td>
      <td style="font-size:.78rem">${t.service}</td>
      <td style="font-family:var(--fh);font-size:.85rem;font-weight:700;color:var(--head)">${t.amount}</td>
      <td><span style="font-size:.72rem;background:var(--bg);padding:.15rem .5rem;border-radius:var(--rad-full);border:1px solid var(--border)">${t.payment}</span></td>
      <td><span class="status-badge status--${t.status}">${t.status.charAt(0).toUpperCase() + t.status.slice(1)}</span></td>
    </tr>
  `).join('');
}

/* ═══════════════════════════════════════════
   11. PET PROFILES
   ══════════════════════════════════════════ */
function renderPets () {
  const grid = document.getElementById('pets-grid');
  if (!grid) return;
  grid.innerHTML = DATA.pets.map(p => `
    <div class="pet-card">
      <span class="pet-card__emoji">${p.emoji}</span>
      <p class="pet-card__name">${p.name}</p>
      <p class="pet-card__breed">${p.breed}</p>
      <p class="pet-card__owner">👤 ${p.owner}</p>
      <span class="pet-card__visits">${p.visits} visits</span>
    </div>
  `).join('');
}

/* ═══════════════════════════════════════════
   12. REVIEWS
   ══════════════════════════════════════════ */
function renderReviews () {
  const grid = document.getElementById('reviews-grid');
  if (!grid) return;

  const stars = r => Array.from({length:5}, (_,i) => `<svg fill="${i < r ? 'var(--gold)' : 'none'}" stroke="var(--gold)" stroke-width="1.5" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`).join('');

  grid.innerHTML = DATA.reviews.map(r => `
    <div class="review-card">
      <div class="rc-top">
        <div class="rc-author">
          <img src="${r.avatar}" alt="${r.author}" class="rc-avatar" loading="lazy" />
          <div>
            <p class="rc-name">${r.author}</p>
            <p class="rc-service">${r.service}</p>
          </div>
        </div>
        <div class="rc-stars">${stars(r.rating)}</div>
      </div>
      <p class="rc-text">${r.text}</p>
      <div class="rc-footer">
        <span class="rc-date">${r.date}</span>
        <div style="display:flex;align-items:center;gap:.5rem">
          <span class="status-badge status--${r.status.replace('pending-review','pending-review').replace(' ','-')}">${r.status.replace('-',' ').replace(/\b\w/g,c=>c.toUpperCase())}</span>
          <div class="rc-actions">
            <button class="tbl-btn" aria-label="Approve" onclick="showToast('Review approved!','success')"><svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="12" height="12"><polyline points="20 6 9 17 4 12"/></svg></button>
            <button class="tbl-btn tbl-btn--del" aria-label="Hide review" onclick="showToast('Review hidden','error')"><svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="12" height="12"><path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94"/></svg></button>
          </div>
        </div>
      </div>
    </div>
  `).join('');
}

/* ═══════════════════════════════════════════
   13. BLOG CMS
   ══════════════════════════════════════════ */
function renderBlog () {
  const grid = document.getElementById('blog-grid');
  if (!grid) return;
  grid.innerHTML = DATA.blogPosts.map(p => `
    <div class="blog-card">
      <img src="${p.img}" alt="${p.title}" class="blog-card__img" loading="lazy" />
      <div class="blog-card__body">
        <p class="blog-card__cat">${p.cat}</p>
        <h4 class="blog-card__title">${p.title}</h4>
        <p class="blog-card__meta">${p.date !== '—' ? p.date : 'Draft'} · ${p.views.toLocaleString('en-IN')} views</p>
        <div class="blog-card__foot">
          <span class="status-badge status--${p.status}">${p.status.charAt(0).toUpperCase() + p.status.slice(1)}</span>
          <div style="display:flex;gap:.375rem">
            <button class="tbl-btn" aria-label="Edit post" onclick="showToast('Opening editor…','info')"><svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="12" height="12"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg></button>
            <button class="tbl-btn tbl-btn--del" aria-label="Delete post" onclick="showToast('Post deleted','error')"><svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" width="12" height="12"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/></svg></button>
          </div>
        </div>
      </div>
    </div>
  `).join('');
}

/* ═══════════════════════════════════════════
   14. MESSAGES
   ══════════════════════════════════════════ */
function renderMessages () {
  const list = document.getElementById('msg-list');
  if (!list) return;
  list.innerHTML = DATA.messages.map(m => `
    <div class="msg-item ${m.unread ? 'unread' : ''}" onclick="showToast('Opening conversation with ${m.name}…','info')">
      <img src="${m.avatar}" alt="${m.name}" class="msg-avatar" loading="lazy" />
      <div class="msg-item__body">
        <p class="msg-item__name">${m.name}</p>
        <p class="msg-item__preview">${m.preview}</p>
      </div>
      <span class="msg-item__time">${m.time}</span>
    </div>
  `).join('');
}

/* ═══════════════════════════════════════════
   15. KPI COUNTER ANIMATIONS
   ══════════════════════════════════════════ */
function initCounters () {
  const els = document.querySelectorAll('[data-counter]');
  const observer = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (!e.isIntersecting) return;
      const el     = e.target;
      const target = parseInt(el.dataset.counter, 10);
      const prefix = el.dataset.prefix || '';
      const dur    = 1800;
      const start  = performance.now();
      const tick   = now => {
        const prog = Math.min((now - start) / dur, 1);
        const ease = 1 - Math.pow(1 - prog, 3);
        el.textContent = prefix + Math.floor(ease * target).toLocaleString('en-IN');
        if (prog < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
      observer.unobserve(el);
    });
  }, { threshold: .5 });
  els.forEach(el => observer.observe(el));
}

/* ═══════════════════════════════════════════
   16. BREED BARS
   ══════════════════════════════════════════ */
function renderBreedBars () {
  const wrap = document.getElementById('breed-bars');
  if (!wrap) return;

  wrap.innerHTML = DATA.breedBreakdown.map(b => `
    <div class="bb-item">
      <div class="bb-top">
        <span class="bb-name">${b.breed}</span>
        <span class="bb-val">${b.count} sessions</span>
      </div>
      <div class="bb-bar">
        <div class="bb-fill" style="width:0%" data-width="${b.pct}%"></div>
      </div>
    </div>
  `).join('');

  // Animate fills
  const fills = wrap.querySelectorAll('.bb-fill');
  const observer = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (!e.isIntersecting) return;
      fills.forEach(f => { f.style.width = f.dataset.width; });
      observer.disconnect();
    });
  }, { threshold: .3 });
  observer.observe(wrap);
}

/* ═══════════════════════════════════════════
   17. ACTIVITY FEED
   ══════════════════════════════════════════ */
function renderActivityFeed () {
  const feed = document.getElementById('activity-feed');
  if (!feed) return;

  const iconMap = {
    booking: { color:'green', svg:'<rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>' },
    review:  { color:'gold',  svg:'<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>' },
    cancel:  { color:'red',   svg:'<circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/>' },
    message: { color:'aqua',  svg:'<path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/>' },
    lav:     { color:'lav',   svg:'<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>' },
  };

  feed.innerHTML = DATA.activityFeed.map(a => {
    const ic = iconMap[a.icon] || iconMap.message;
    return `
      <li class="activity-item">
        <div class="act-icon act-icon--${ic.color}">
          <svg fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">${ic.svg}</svg>
        </div>
        <div class="act-body">
          <p class="act-text">${a.text}</p>
          <p class="act-time">${a.time}</p>
        </div>
      </li>
    `;
  }).join('');
}

/* ═══════════════════════════════════════════
   18. GROOMER LEADERBOARD
   ══════════════════════════════════════════ */
function renderGroomers () {
  const list = document.getElementById('groomer-list');
  if (!list) return;

  list.innerHTML = DATA.groomers.map((g, i) => `
    <li class="groomer-item">
      <span class="groomer-item__rank">#${i+1}</span>
      <img src="${g.avatar}" alt="${g.name}" class="groomer-item__avatar" loading="lazy" />
      <div class="groomer-item__info">
        <p class="groomer-item__name">${g.name}</p>
        <p class="groomer-item__sessions">${g.sessions} sessions · ${g.role}</p>
      </div>
      <span class="groomer-item__rating">★ ${g.rating}</span>
    </li>
  `).join('');
}

/* ═══════════════════════════════════════════
   19. TOAST NOTIFICATIONS
   ══════════════════════════════════════════ */
function showToast (msg, type = 'info', duration = 3500) {
  let wrap = document.getElementById('dash-toast-wrap');
  if (!wrap) {
    wrap = document.createElement('div');
    wrap.id = 'dash-toast-wrap';
    wrap.className = 'dash-toast-wrap';
    wrap.setAttribute('aria-live', 'polite');
    document.body.appendChild(wrap);
  }

  const icons = {
    success: '✓',
    error:   '✕',
    info:    'ℹ',
  };

  const toast = document.createElement('div');
  toast.className = `dash-toast ${type}`;
  toast.innerHTML = `<span style="font-size:.9rem;flex-shrink:0">${icons[type] || '🔔'}</span><span style="flex:1">${msg}</span><button onclick="this.parentElement.remove()" style="background:none;border:none;cursor:pointer;color:var(--muted);font-size:.85rem;padding:.1rem .2rem" aria-label="Dismiss">✕</button>`;
  wrap.appendChild(toast);

  setTimeout(() => {
    toast.style.transition = 'opacity .25s, transform .25s';
    toast.style.opacity    = '0';
    toast.style.transform  = 'translateX(60px)';
    setTimeout(() => toast.remove(), 260);
  }, duration);
}

// Expose globally so inline onclick handlers work
window.showToast = showToast;

/* ═══════════════════════════════════════════
   ENTRY POINT
   ══════════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  initNav();
  initNotifications();

  // Render all data
  renderRevenueChart();
  renderDonutChart();
  renderBookingsTable();
  renderAllBookings();
  renderCustomers();
  renderServices();
  renderRevenueTable();
  renderPets();
  renderReviews();
  renderBlog();
  renderMessages();
  renderGroomers();
  renderActivityFeed();
  renderBreedBars();
  initCounters();

  // Re-render chart on theme change
  document.getElementById('dash-theme')?.addEventListener('click', () => {
    setTimeout(renderRevenueChart, 50);
  });

  // Chart period button toggling
  document.querySelectorAll('.cpb').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.cpb').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      showToast(`Showing ${btn.textContent} revenue data`, 'info');
    });
  });

  // Filter tabs in bookings section
  document.querySelectorAll('.filter-tabs .ftab').forEach(tab => {
    tab.addEventListener('click', () => {
      tab.closest('.filter-tabs').querySelectorAll('.ftab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
    });
  });

  // Welcome toast
  setTimeout(() => showToast('Welcome back, Ananya! You have 8 unread notifications 🐾', 'success'), 800);
});
