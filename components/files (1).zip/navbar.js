/**
 * ============================================================
 * PawSpa — navbar.js  (FIXED)
 * Navbar-specific JavaScript.
 * Handles: scroll state, mobile menu, dropdowns with
 * intentional hover delay, hamburger animation, active
 * link highlighting, and keyboard accessibility.
 *
 * FIX LOG:
 *  1. Mobile menu: CSS keeps display:none; JS now explicitly
 *     sets display:flex before animating and restores after.
 *  2. Auto-run: initNavbarComponent() is now called on
 *     DOMContentLoaded when the navbar is already in the DOM
 *     (no global.js needed for static pages).
 *  3. initBookNowButtons: robust null-guard added.
 * ============================================================
 */

'use strict';

/* ─────────────────────────────────────────────
   1. SCROLL BEHAVIOUR
   Adds .scrolled class to .navbar after 20px scroll.
   ───────────────────────────────────────────── */

function initNavbarScroll() {
  const navbar = document.querySelector('.navbar');
  if (!navbar) return;

  const handler = () => {
    navbar.classList.toggle('scrolled', window.scrollY > 20);
  };

  let ticking = false;
  window.addEventListener('scroll', () => {
    if (!ticking) {
      requestAnimationFrame(() => {
        handler();
        ticking = false;
      });
      ticking = true;
    }
  }, { passive: true });

  handler();
}

/* ─────────────────────────────────────────────
   2. DROPDOWN HOVER WITH INTENT DELAY
   ───────────────────────────────────────────── */

function initDropdownHover() {
  const navItems = document.querySelectorAll('.nav-item');
  const CLOSE_DELAY = 280;

  navItems.forEach(item => {
    let closeTimer = null;

    const openDropdown = () => {
      clearTimeout(closeTimer);
      navItems.forEach(other => {
        if (other !== item) {
          other.classList.remove('hovered');
          const otherLink = other.querySelector(':scope > .nav-link');
          if (otherLink) otherLink.setAttribute('aria-expanded', 'false');
        }
      });
      item.classList.add('hovered');
      const link = item.querySelector(':scope > .nav-link');
      if (link) link.setAttribute('aria-expanded', 'true');
    };

    const closeDropdown = () => {
      closeTimer = setTimeout(() => {
        item.classList.remove('hovered');
        const link = item.querySelector(':scope > .nav-link');
        if (link) link.setAttribute('aria-expanded', 'false');
      }, CLOSE_DELAY);
    };

    item.addEventListener('mouseenter', openDropdown);
    item.addEventListener('mouseleave', closeDropdown);

    const parentLink = item.querySelector(':scope > .nav-link');
    if (parentLink && item.querySelector('.dropdown-menu')) {
      parentLink.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          const isOpen = item.classList.contains('hovered');
          if (isOpen) {
            item.classList.remove('hovered');
            parentLink.setAttribute('aria-expanded', 'false');
          } else {
            openDropdown();
            const first = item.querySelector('.dropdown-item');
            if (first) setTimeout(() => first.focus(), 50);
          }
        }
        if (e.key === 'Escape') {
          item.classList.remove('hovered');
          parentLink.setAttribute('aria-expanded', 'false');
          parentLink.focus();
        }
      });

      const dropdown = item.querySelector('.dropdown-menu');
      if (dropdown) {
        dropdown.addEventListener('keydown', (e) => {
          const items = [...dropdown.querySelectorAll('.dropdown-item')];
          const index = items.indexOf(document.activeElement);

          if (e.key === 'ArrowDown') {
            e.preventDefault();
            const next = items[index + 1] || items[0];
            next.focus();
          }
          if (e.key === 'ArrowUp') {
            e.preventDefault();
            const prev = items[index - 1] || items[items.length - 1];
            prev.focus();
          }
          if (e.key === 'Escape') {
            e.preventDefault();
            item.classList.remove('hovered');
            parentLink.setAttribute('aria-expanded', 'false');
            parentLink.focus();
          }
          if (e.key === 'Tab') {
            setTimeout(() => {
              if (!item.contains(document.activeElement)) {
                item.classList.remove('hovered');
                parentLink.setAttribute('aria-expanded', 'false');
              }
            }, 0);
          }
        });
      }
    }
  });

  document.addEventListener('click', (e) => {
    if (!e.target.closest('.nav-item')) {
      navItems.forEach(item => {
        item.classList.remove('hovered');
        const link = item.querySelector(':scope > .nav-link');
        if (link) link.setAttribute('aria-expanded', 'false');
      });
    }
  });
}

/* ─────────────────────────────────────────────
   3. MOBILE MENU
   FIX: The CSS keeps .mobile-menu at display:none.
   We must set display:flex BEFORE adding .open so
   the CSS transition actually runs. On close, we
   wait for the transition to finish before hiding.
   ───────────────────────────────────────────── */

function initMobileMenu() {
  const toggleBtns = document.querySelectorAll('[data-mobile-toggle]');
  const menu       = document.getElementById('mobile-menu');
  // FIX: look for both id="mobile-overlay" and class="mobile-overlay"
  const overlay    = document.getElementById('mobile-overlay') ||
                     document.querySelector('.mobile-overlay, .overlay[aria-hidden]');
  const hamOpen    = document.querySelector('.ham-open');
  const hamClose   = document.querySelector('.ham-close');

  if (!menu) return;

  let isOpen = false;
  let closeTransitionTimer = null;

  // Transition duration must match CSS (0.35s = 350ms)
  const TRANSITION_MS = 350;

  function openMenu() {
    clearTimeout(closeTransitionTimer);
    isOpen = true;

    // FIX: make the element visible BEFORE adding .open so transform animates
    menu.style.display = 'flex';
    // Force a reflow so the browser registers the display change
    // before applying the .open class (otherwise no transition)
    menu.getBoundingClientRect(); // eslint-disable-line no-unused-expressions

    menu.classList.add('open');
    menu.removeAttribute('aria-hidden');

    if (overlay) {
      overlay.style.display = 'block';
      overlay.getBoundingClientRect();
      overlay.classList.add('open');
      overlay.setAttribute('aria-hidden', 'false');
    }

    document.body.style.overflow = 'hidden';
    toggleBtns.forEach(btn => btn.setAttribute('aria-expanded', 'true'));

    if (hamOpen)  hamOpen.style.display  = 'none';
    if (hamClose) hamClose.style.display = 'block';

    const firstLink = menu.querySelector('.mobile-nav-link, a');
    if (firstLink) setTimeout(() => firstLink.focus(), 300);
  }

  function closeMenu() {
    isOpen = false;
    menu.classList.remove('open');
    menu.setAttribute('aria-hidden', 'true');

    if (overlay) {
      overlay.classList.remove('open');
      overlay.setAttribute('aria-hidden', 'true');
    }

    document.body.style.overflow = '';
    toggleBtns.forEach(btn => btn.setAttribute('aria-expanded', 'false'));

    if (hamOpen)  hamOpen.style.display  = 'block';
    if (hamClose) hamClose.style.display = 'none';

    // FIX: hide element AFTER the slide-out transition finishes
    closeTransitionTimer = setTimeout(() => {
      menu.style.display = '';
      if (overlay) overlay.style.display = '';
    }, TRANSITION_MS);
  }

  toggleBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      isOpen ? closeMenu() : openMenu();
    });
  });

  if (overlay) {
    overlay.addEventListener('click', closeMenu);
  }

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && isOpen) {
      closeMenu();
      const firstToggle = document.querySelector('[data-mobile-toggle]');
      if (firstToggle) firstToggle.focus();
    }
  });

  menu.addEventListener('keydown', (e) => {
    if (!isOpen || e.key !== 'Tab') return;
    const focusable = menu.querySelectorAll(
      'a[href], button:not([disabled]), input, select, textarea, [tabindex]:not([tabindex="-1"])'
    );
    const first = focusable[0];
    const last  = focusable[focusable.length - 1];

    if (e.shiftKey) {
      if (document.activeElement === first) {
        e.preventDefault();
        last.focus();
      }
    } else {
      if (document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    }
  });

  /* ── Accordion sub-menus ───────────────────── */
  const accordionBtns = menu.querySelectorAll('[data-mobile-accordion]');
  accordionBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const sub     = btn.nextElementSibling;
      const chevron = btn.querySelector('.mobile-chevron');
      if (!sub) return;

      const isExpanded = btn.classList.contains('active');

      accordionBtns.forEach(otherBtn => {
        if (otherBtn !== btn && otherBtn.classList.contains('active')) {
          otherBtn.classList.remove('active');
          otherBtn.setAttribute('aria-expanded', 'false');
          const otherSub     = otherBtn.nextElementSibling;
          const otherChevron = otherBtn.querySelector('.mobile-chevron');
          if (otherSub) otherSub.style.maxHeight = '0px';
          if (otherChevron) otherChevron.style.transform = 'rotate(0deg)';
        }
      });

      if (isExpanded) {
        btn.classList.remove('active');
        btn.setAttribute('aria-expanded', 'false');
        sub.style.maxHeight = '0px';
        if (chevron) chevron.style.transform = 'rotate(0deg)';
      } else {
        btn.classList.add('active');
        btn.setAttribute('aria-expanded', 'true');
        sub.style.maxHeight = sub.scrollHeight + 'px';
        if (chevron) chevron.style.transform = 'rotate(180deg)';
      }
    });
  });

  menu.querySelectorAll('a[href]').forEach(link => {
    link.addEventListener('click', () => {
      setTimeout(closeMenu, 100);
    });
  });
}

/* ─────────────────────────────────────────────
   4. ACTIVE LINK HIGHLIGHTING
   ───────────────────────────────────────────── */

function highlightActiveNavLink() {
  const currentPath = window.location.pathname;

  const allLinks = document.querySelectorAll(
    '.nav-link, .dropdown-item, .mobile-nav-link--plain, .mobile-submenu-link'
  );

  allLinks.forEach(link => {
    const href = link.getAttribute('href');
    if (!href || href === '#' || href.startsWith('#')) return;

    try {
      const linkPath = new URL(href, window.location.href).pathname;

      const isActive =
        linkPath === currentPath ||
        (currentPath.endsWith('/') && linkPath === currentPath + 'index.html') ||
        (linkPath.endsWith('/index.html') && linkPath.replace('/index.html', '/') === currentPath);

      if (isActive) {
        link.classList.add('active');

        const parentNavItem = link.closest('.nav-item');
        if (parentNavItem) {
          const parentLink = parentNavItem.querySelector(':scope > .nav-link');
          if (parentLink) parentLink.classList.add('active');
        }

        const parentAccordion = link.closest('.mobile-submenu');
        if (parentAccordion) {
          const accordionBtn = parentAccordion.previousElementSibling;
          if (accordionBtn) accordionBtn.classList.add('active');
        }
      }
    } catch {
      // Invalid URL — skip
    }
  });
}

/* ─────────────────────────────────────────────
   5. STICKY HEADER OFFSET HELPER
   ───────────────────────────────────────────── */

function initPageOffset() {
  const main   = document.querySelector('main');
  const navbar = document.querySelector('.navbar');
  if (!navbar) return;

  const updateOffset = () => {
    const h = navbar.offsetHeight;
    document.documentElement.style.setProperty('--navbar-height', h + 'px');
    if (main && main.classList.contains('page-offset')) {
      main.style.paddingTop = h + 'px';
    }
  };

  updateOffset();
  window.addEventListener('resize', updateOffset, { passive: true });
}

/* ─────────────────────────────────────────────
   6. BOOK NOW BUTTON WIRING
   ───────────────────────────────────────────── */

function initBookNowButtons() {
  document.querySelectorAll('[data-book-now]').forEach(btn => {
    if (!btn.parentNode) return;
    const newBtn = btn.cloneNode(true);
    btn.parentNode.replaceChild(newBtn, btn);

    newBtn.addEventListener('click', (e) => {
      e.preventDefault();
      if (window.PawSpa && window.PawSpa.openModal) {
        window.PawSpa.openModal('booking-modal');
      } else {
        const contact = document.getElementById('contact-form') ||
                        document.querySelector('.contact-section');
        if (contact) {
          contact.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }
    });
  });
}

/* ─────────────────────────────────────────────
   7. ENTRY POINT
   ───────────────────────────────────────────── */

function initNavbarComponent() {
  initNavbarScroll();
  initDropdownHover();
  initMobileMenu();
  highlightActiveNavLink();
  initPageOffset();
  setTimeout(initBookNowButtons, 50);
}

/* ─────────────────────────────────────────────
   8. EXPORT / ATTACH
   ───────────────────────────────────────────── */

window.initNavbarComponent = initNavbarComponent;

// FIX: Auto-run when the navbar is already in the DOM
// (handles static pages where global.js doesn't inject the navbar)
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initNavbarComponent);
} else {
  // DOM already ready (script loaded with defer or at end of body)
  initNavbarComponent();
}
