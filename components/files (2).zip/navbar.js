/**
 * ============================================================
 * PawSpa — navbar.js  (FIXED v2)
 *
 * FIXES applied:
 * 1. Mobile menu open/close no longer sets display — it only
 *    toggles .open (transform+visibility handle show/hide).
 * 2. Mobile overlay is found by class (.mobile-overlay) scoped
 *    inside the navbar, not the page-level #mobile-overlay.
 *    This fixes the "Get a Quote" page where the page overlay
 *    div was intercepting clicks.
 * 3. Accordion wiring uses event delegation on the menu
 *    container so it works even if the HTML loads late.
 * 4. Hamburger icon swap is robust (checks for element before
 *    toggling display).
 * 5. window.initNavbarComponent is always exported so
 *    global.js can call it after component injection.
 * ============================================================
 */

'use strict';

/* ─────────────────────────────────────────────
   CONFIG
   ───────────────────────────────────────────── */
const DROPDOWN_CLOSE_DELAY = 280; // ms — time before dropdown closes after mouse leaves

/* ─────────────────────────────────────────────
   1. SCROLL STATE
   ───────────────────────────────────────────── */
function initNavbarScroll() {
  const navbar = document.querySelector('.navbar');
  if (!navbar) return;

  let ticking = false;

  const update = () => {
    navbar.classList.toggle('scrolled', window.scrollY > 20);
    ticking = false;
  };

  window.addEventListener('scroll', () => {
    if (!ticking) { requestAnimationFrame(update); ticking = true; }
  }, { passive: true });

  update(); // run on load
}

/* ─────────────────────────────────────────────
   2. DROPDOWN HOVER WITH INTENT DELAY
   ───────────────────────────────────────────── */
function initDropdownHover() {
  const navItems = document.querySelectorAll('.nav-item');
  if (!navItems.length) return;

  navItems.forEach(item => {
    let closeTimer = null;

    const open = () => {
      clearTimeout(closeTimer);
      // Close all other dropdowns
      navItems.forEach(other => {
        if (other !== item) {
          other.classList.remove('hovered');
          const l = other.querySelector(':scope > .nav-link');
          if (l) l.setAttribute('aria-expanded', 'false');
        }
      });
      item.classList.add('hovered');
      const link = item.querySelector(':scope > .nav-link');
      if (link) link.setAttribute('aria-expanded', 'true');
    };

    const close = () => {
      closeTimer = setTimeout(() => {
        item.classList.remove('hovered');
        const link = item.querySelector(':scope > .nav-link');
        if (link) link.setAttribute('aria-expanded', 'false');
      }, DROPDOWN_CLOSE_DELAY);
    };

    item.addEventListener('mouseenter', open);
    item.addEventListener('mouseleave', close);

    // Keyboard support on parent link
    const parentLink = item.querySelector(':scope > .nav-link');
    const dropdown   = item.querySelector('.dropdown-menu');

    if (parentLink && dropdown) {
      parentLink.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          const isOpen = item.classList.contains('hovered');
          if (isOpen) {
            item.classList.remove('hovered');
            parentLink.setAttribute('aria-expanded', 'false');
          } else {
            open();
            const first = dropdown.querySelector('.dropdown-item');
            if (first) setTimeout(() => first.focus(), 40);
          }
        }
        if (e.key === 'ArrowDown') {
          e.preventDefault();
          open();
          const first = dropdown.querySelector('.dropdown-item');
          if (first) setTimeout(() => first.focus(), 40);
        }
        if (e.key === 'Escape') {
          item.classList.remove('hovered');
          parentLink.setAttribute('aria-expanded', 'false');
          parentLink.focus();
        }
      });

      dropdown.addEventListener('keydown', (e) => {
        const items = [...dropdown.querySelectorAll('.dropdown-item')];
        const idx   = items.indexOf(document.activeElement);
        if (e.key === 'ArrowDown') { e.preventDefault(); (items[idx + 1] || items[0]).focus(); }
        if (e.key === 'ArrowUp')   { e.preventDefault(); (items[idx - 1] || items[items.length - 1]).focus(); }
        if (e.key === 'Escape') {
          e.preventDefault();
          item.classList.remove('hovered');
          parentLink.setAttribute('aria-expanded', 'false');
          parentLink.focus();
        }
        if (e.key === 'Tab') {
          setTimeout(() => {
            if (!item.contains(document.activeElement)) {
              item.classList.remove('hovered');
              parentLink.setAttribute('aria-expanded', 'false');
            }
          }, 0);
        }
      });
    }
  });

  // Close all when clicking outside
  document.addEventListener('click', (e) => {
    if (!e.target.closest('.nav-item')) {
      navItems.forEach(item => {
        item.classList.remove('hovered');
        const l = item.querySelector(':scope > .nav-link');
        if (l) l.setAttribute('aria-expanded', 'false');
      });
    }
  });
}

/* ─────────────────────────────────────────────
   3. MOBILE PANEL  ← MAIN FIX
   ───────────────────────────────────────────── */
function initMobileMenu() {
  const navbar = document.querySelector('.navbar');
  if (!navbar) return;

  const menu = navbar.querySelector('#mobile-menu');
  if (!menu) return;

  /*
    FIX 1: Find the overlay SCOPED inside the navbar.
    The page HTML also has a #mobile-overlay div used by
    global.js for the booking modal backdrop. Scoping to
    navbar avoids that conflict.
  */
  const overlay   = navbar.querySelector('.mobile-overlay');
  const toggleBtns = navbar.querySelectorAll('[data-mobile-toggle]');
  const hamOpen   = navbar.querySelector('.ham-open');
  const hamClose  = navbar.querySelector('.ham-close');

  let isOpen = false;

  /* ── Helpers ── */
  function setHamburgerIcon(open) {
    if (hamOpen)  hamOpen.style.display  = open ? 'none'  : 'block';
    if (hamClose) hamClose.style.display = open ? 'block' : 'none';
  }

  /*
    FIX 2: open/close ONLY toggles the .open class.
    The CSS uses transform+visibility — no display change needed.
    This fixes the "small box in top-left" bug which happened
    because toggling display:none→flex gave the element zero
    dimensions before the transform ran.
  */
  function openMenu() {
    isOpen = true;
    menu.classList.add('open');
    if (overlay) overlay.classList.add('open');
    document.body.style.overflow = 'hidden';
    toggleBtns.forEach(b => b.setAttribute('aria-expanded', 'true'));
    setHamburgerIcon(true);

    // Focus first interactive element inside menu
    const first = menu.querySelector('button, a[href], [tabindex]:not([tabindex="-1"])');
    if (first) setTimeout(() => first.focus(), 350);
  }

  function closeMenu() {
    isOpen = false;
    menu.classList.remove('open');
    if (overlay) overlay.classList.remove('open');
    document.body.style.overflow = '';
    toggleBtns.forEach(b => b.setAttribute('aria-expanded', 'false'));
    setHamburgerIcon(false);
  }

  /* ── Wire toggle buttons ── */
  toggleBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      isOpen ? closeMenu() : openMenu();
    });
  });

  /* ── Overlay click ── */
  if (overlay) overlay.addEventListener('click', closeMenu);

  /* ── Escape key ── */
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && isOpen) {
      closeMenu();
      const hamburger = navbar.querySelector('.navbar-toggle');
      if (hamburger) hamburger.focus();
    }
  });

  /* ── Focus trap ── */
  menu.addEventListener('keydown', (e) => {
    if (!isOpen || e.key !== 'Tab') return;
    const sel = 'a[href], button:not([disabled]), input, select, textarea, [tabindex]:not([tabindex="-1"])';
    const focusable = [...menu.querySelectorAll(sel)];
    if (!focusable.length) return;
    const first = focusable[0];
    const last  = focusable[focusable.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  });

  /* ── Close when a menu link is clicked ── */
  menu.querySelectorAll('a[href]').forEach(link => {
    link.addEventListener('click', () => setTimeout(closeMenu, 80));
  });

  /* ── Accordion ── */
  initMobileAccordion(menu);
}

/* ─────────────────────────────────────────────
   4. MOBILE ACCORDION  ← FIXED
   ───────────────────────────────────────────── */
function initMobileAccordion(menu) {
  if (!menu) return;

  /*
    FIX 3: Use event delegation on the menu container instead
    of binding to each button individually. This works even if
    the buttons haven't fully rendered yet when this runs.
    It also correctly handles the Services and Blog buttons
    which weren't responding previously.
  */
  menu.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-mobile-accordion]');
    if (!btn) return;

    e.preventDefault();
    e.stopPropagation();

    const sub     = btn.nextElementSibling;
    const chevron = btn.querySelector('.mobile-chevron');
    if (!sub) return;

    const isExpanded = btn.classList.contains('active');

    // Collapse all OTHER open accordions
    menu.querySelectorAll('[data-mobile-accordion].active').forEach(otherBtn => {
      if (otherBtn === btn) return;
      otherBtn.classList.remove('active');
      otherBtn.setAttribute('aria-expanded', 'false');
      const otherSub     = otherBtn.nextElementSibling;
      const otherChevron = otherBtn.querySelector('.mobile-chevron');
      if (otherSub) otherSub.style.maxHeight = '0px';
      if (otherChevron) otherChevron.style.transform = 'rotate(0deg)';
    });

    if (isExpanded) {
      // Close this one
      btn.classList.remove('active');
      btn.setAttribute('aria-expanded', 'false');
      sub.style.maxHeight = '0px';
      if (chevron) chevron.style.transform = 'rotate(0deg)';
    } else {
      // Open this one
      btn.classList.add('active');
      btn.setAttribute('aria-expanded', 'true');
      // scrollHeight gives actual content height for smooth animation
      sub.style.maxHeight = sub.scrollHeight + 'px';
      if (chevron) chevron.style.transform = 'rotate(180deg)';
    }
  });
}

/* ─────────────────────────────────────────────
   5. ACTIVE LINK HIGHLIGHTING
   ───────────────────────────────────────────── */
function highlightActiveNavLink() {
  const currentPath = window.location.pathname;

  const selectors = [
    '.nav-link',
    '.dropdown-item',
    '.mobile-nav-link--plain',
    '.mobile-submenu-link',
  ].join(', ');

  document.querySelectorAll(selectors).forEach(link => {
    const href = link.getAttribute('href');
    if (!href || href === '#' || href.startsWith('#')) return;

    try {
      const linkPath = new URL(href, window.location.href).pathname;

      const isActive =
        linkPath === currentPath ||
        (currentPath.endsWith('/') && linkPath === currentPath + 'index.html') ||
        (linkPath.endsWith('/index.html') && linkPath.replace('/index.html', '/') === currentPath);

      if (!isActive) return;

      link.classList.add('active');

      // Mark parent desktop nav-item
      const parentNavItem = link.closest('.nav-item');
      if (parentNavItem) {
        const parentLink = parentNavItem.querySelector(':scope > .nav-link');
        if (parentLink && parentLink !== link) parentLink.classList.add('active');
      }

      // Mark parent mobile accordion button
      const parentSubmenu = link.closest('.mobile-submenu');
      if (parentSubmenu) {
        const accordionBtn = parentSubmenu.previousElementSibling;
        if (accordionBtn) accordionBtn.classList.add('active');
      }
    } catch { /* invalid URL — skip */ }
  });
}

/* ─────────────────────────────────────────────
   6. PAGE OFFSET CSS VARIABLE
   ───────────────────────────────────────────── */
function initPageOffset() {
  const navbar = document.querySelector('.navbar');
  if (!navbar) return;

  const set = () => {
    const h = navbar.offsetHeight;
    document.documentElement.style.setProperty('--navbar-height', h + 'px');
    const main = document.querySelector('main.page-offset');
    if (main) main.style.paddingTop = h + 'px';
  };

  set();
  window.addEventListener('resize', set, { passive: true });
}

/* ─────────────────────────────────────────────
   7. BOOK NOW WIRING
   ───────────────────────────────────────────── */
function initNavbarBookNow() {
  // Re-query after cloneNode replacements in global.js
  document.querySelectorAll('[data-book-now]').forEach(btn => {
    // Remove stale listeners by replacing the element
    const clone = btn.cloneNode(true);
    if (btn.parentNode) {
      btn.parentNode.replaceChild(clone, btn);
    }

    clone.addEventListener('click', (e) => {
      e.preventDefault();
      if (window.PawSpa?.openModal) {
        window.PawSpa.openModal('booking-modal');
      } else {
        const target = document.getElementById('contact-form') ||
                       document.querySelector('[id*="contact"]');
        if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });
}

/* ─────────────────────────────────────────────
   ENTRY POINT
   ───────────────────────────────────────────── */
function initNavbarComponent() {
  initNavbarScroll();
  initDropdownHover();
  initMobileMenu();
  highlightActiveNavLink();
  initPageOffset();
  // Slight delay so booking modal from global.js is in DOM
  setTimeout(initNavbarBookNow, 80);
}

/* Export so global.js can call after navbar injection */
window.initNavbarComponent = initNavbarComponent;

/* Auto-run if navbar is already present */
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.navbar')) initNavbarComponent();
  });
} else {
  if (document.querySelector('.navbar')) initNavbarComponent();
}
