/**
 * ============================================================
 * PawSpa — navbar.js
 * Navbar-specific JavaScript.
 * Handles: scroll state, mobile menu, dropdowns with
 * intentional hover delay, hamburger animation, active
 * link highlighting, and keyboard accessibility.
 *
 * NOTE: Theme toggle & RTL toggle wiring is handled in
 * global.js after the navbar component is injected.
 * This file adds ADDITIONAL navbar-specific behaviour.
 * ============================================================
 */

'use strict';

/* ─────────────────────────────────────────────
   1. SCROLL BEHAVIOUR
   Adds .scrolled class to .navbar after 20px scroll.
   ───────────────────────────────────────────── */

function initNavbarScroll() {
  const navbar = document.querySelector('.navbar');
  if (!navbar) return;

  const handler = () => {
    navbar.classList.toggle('scrolled', window.scrollY > 20);
  };

  // Throttle for performance
  let ticking = false;
  window.addEventListener('scroll', () => {
    if (!ticking) {
      requestAnimationFrame(() => {
        handler();
        ticking = false;
      });
      ticking = true;
    }
  }, { passive: true });

  // Run once on init
  handler();
}

/* ─────────────────────────────────────────────
   2. DROPDOWN HOVER WITH INTENT DELAY
   Uses a configurable close delay so the user
   can move the mouse to the dropdown without
   it disappearing.
   ───────────────────────────────────────────── */

function initDropdownHover() {
  const navItems = document.querySelectorAll('.nav-item');

  /**
   * Delay (ms) before the dropdown closes after
   * the mouse leaves the nav item.
   * Keep >= 200 so users can reach the dropdown.
   */
  const CLOSE_DELAY = 280;

  navItems.forEach(item => {
    let closeTimer = null;

    const openDropdown = () => {
      clearTimeout(closeTimer);
      // Close all other dropdowns first
      navItems.forEach(other => {
        if (other !== item) {
          other.classList.remove('hovered');
          const otherLink = other.querySelector(':scope > .nav-link');
          if (otherLink) otherLink.setAttribute('aria-expanded', 'false');
        }
      });
      item.classList.add('hovered');
      const link = item.querySelector(':scope > .nav-link');
      if (link) link.setAttribute('aria-expanded', 'true');
    };

    const closeDropdown = () => {
      closeTimer = setTimeout(() => {
        item.classList.remove('hovered');
        const link = item.querySelector(':scope > .nav-link');
        if (link) link.setAttribute('aria-expanded', 'false');
      }, CLOSE_DELAY);
    };

    item.addEventListener('mouseenter', openDropdown);
    item.addEventListener('mouseleave', closeDropdown);

    // Keyboard: open on Enter/Space for parent links
    const parentLink = item.querySelector(':scope > .nav-link');
    if (parentLink && item.querySelector('.dropdown-menu')) {
      parentLink.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          const isOpen = item.classList.contains('hovered');
          if (isOpen) {
            item.classList.remove('hovered');
            parentLink.setAttribute('aria-expanded', 'false');
          } else {
            openDropdown();
            // Focus first dropdown item
            const first = item.querySelector('.dropdown-item');
            if (first) setTimeout(() => first.focus(), 50);
          }
        }
        // Close on Escape
        if (e.key === 'Escape') {
          item.classList.remove('hovered');
          parentLink.setAttribute('aria-expanded', 'false');
          parentLink.focus();
        }
      });

      // Arrow key navigation within dropdown
      const dropdown = item.querySelector('.dropdown-menu');
      if (dropdown) {
        dropdown.addEventListener('keydown', (e) => {
          const items = [...dropdown.querySelectorAll('.dropdown-item')];
          const index = items.indexOf(document.activeElement);

          if (e.key === 'ArrowDown') {
            e.preventDefault();
            const next = items[index + 1] || items[0];
            next.focus();
          }
          if (e.key === 'ArrowUp') {
            e.preventDefault();
            const prev = items[index - 1] || items[items.length - 1];
            prev.focus();
          }
          if (e.key === 'Escape') {
            e.preventDefault();
            item.classList.remove('hovered');
            parentLink.setAttribute('aria-expanded', 'false');
            parentLink.focus();
          }
          if (e.key === 'Tab') {
            // Close dropdown when tabbing out
            setTimeout(() => {
              if (!item.contains(document.activeElement)) {
                item.classList.remove('hovered');
                parentLink.setAttribute('aria-expanded', 'false');
              }
            }, 0);
          }
        });
      }
    }
  });

  // Close all dropdowns when clicking outside
  document.addEventListener('click', (e) => {
    if (!e.target.closest('.nav-item')) {
      navItems.forEach(item => {
        item.classList.remove('hovered');
        const link = item.querySelector(':scope > .nav-link');
        if (link) link.setAttribute('aria-expanded', 'false');
      });
    }
  });
}

/* ─────────────────────────────────────────────
   3. MOBILE MENU
   Slide-in panel with accordion sub-menus.
   ───────────────────────────────────────────── */

function initMobileMenu() {
  const toggleBtns = document.querySelectorAll('[data-mobile-toggle]');
  const menu       = document.getElementById('mobile-menu');
  const overlay    = document.getElementById('mobile-overlay');
  const hamOpen    = document.querySelector('.ham-open');
  const hamClose   = document.querySelector('.ham-close');

  if (!menu) return;

  let isOpen = false;

  /* ── Open / Close helpers ──────────────────── */
  function openMenu() {
    isOpen = true;
    menu.classList.add('open');
    if (overlay) overlay.classList.add('open');
    document.body.style.overflow = 'hidden';

    // Update all toggle buttons
    toggleBtns.forEach(btn => btn.setAttribute('aria-expanded', 'true'));

    // Toggle hamburger icons
    if (hamOpen)  hamOpen.style.display  = 'none';
    if (hamClose) hamClose.style.display = 'block';

    // Focus first link inside menu for accessibility
    const firstLink = menu.querySelector('.mobile-nav-link, a');
    if (firstLink) setTimeout(() => firstLink.focus(), 300);
  }

  function closeMenu() {
    isOpen = false;
    menu.classList.remove('open');
    if (overlay) overlay.classList.remove('open');
    document.body.style.overflow = '';

    // Update all toggle buttons
    toggleBtns.forEach(btn => btn.setAttribute('aria-expanded', 'false'));

    // Toggle hamburger icons
    if (hamOpen)  hamOpen.style.display  = 'block';
    if (hamClose) hamClose.style.display = 'none';
  }

  /* ── Wire toggle buttons ───────────────────── */
  toggleBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      isOpen ? closeMenu() : openMenu();
    });
  });

  /* ── Overlay click closes menu ─────────────── */
  if (overlay) {
    overlay.addEventListener('click', closeMenu);
  }

  /* ── Escape key closes menu ────────────────── */
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && isOpen) {
      closeMenu();
      // Return focus to toggle button
      const firstToggle = document.querySelector('[data-mobile-toggle]');
      if (firstToggle) firstToggle.focus();
    }
  });

  /* ── Focus trap inside mobile menu ────────── */
  menu.addEventListener('keydown', (e) => {
    if (!isOpen || e.key !== 'Tab') return;
    const focusable = menu.querySelectorAll(
      'a[href], button:not([disabled]), input, select, textarea, [tabindex]:not([tabindex="-1"])'
    );
    const first = focusable[0];
    const last  = focusable[focusable.length - 1];

    if (e.shiftKey) {
      if (document.activeElement === first) {
        e.preventDefault();
        last.focus();
      }
    } else {
      if (document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    }
  });

  /* ── Accordion sub-menus ───────────────────── */
  const accordionBtns = menu.querySelectorAll('[data-mobile-accordion]');
  accordionBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const sub     = btn.nextElementSibling;
      const chevron = btn.querySelector('.mobile-chevron');
      if (!sub) return;

      const isExpanded = btn.classList.contains('active');

      // Collapse all other accordions
      accordionBtns.forEach(otherBtn => {
        if (otherBtn !== btn && otherBtn.classList.contains('active')) {
          otherBtn.classList.remove('active');
          otherBtn.setAttribute('aria-expanded', 'false');
          const otherSub     = otherBtn.nextElementSibling;
          const otherChevron = otherBtn.querySelector('.mobile-chevron');
          if (otherSub) otherSub.style.maxHeight = '0px';
          if (otherChevron) otherChevron.style.transform = 'rotate(0deg)';
        }
      });

      if (isExpanded) {
        // Close this accordion
        btn.classList.remove('active');
        btn.setAttribute('aria-expanded', 'false');
        sub.style.maxHeight = '0px';
        if (chevron) chevron.style.transform = 'rotate(0deg)';
      } else {
        // Open this accordion
        btn.classList.add('active');
        btn.setAttribute('aria-expanded', 'true');
        sub.style.maxHeight = sub.scrollHeight + 'px';
        if (chevron) chevron.style.transform = 'rotate(180deg)';
      }
    });
  });

  /* ── Close menu when a nav link is clicked ── */
  menu.querySelectorAll('a[href]').forEach(link => {
    link.addEventListener('click', () => {
      // Small delay so the user sees the click
      setTimeout(closeMenu, 100);
    });
  });
}

/* ─────────────────────────────────────────────
   4. ACTIVE LINK HIGHLIGHTING
   Compares current URL path to each nav/dropdown
   link href and adds .active class.
   ───────────────────────────────────────────── */

function highlightActiveNavLink() {
  const currentPath = window.location.pathname;

  // Desktop nav links + dropdown items
  const allLinks = document.querySelectorAll(
    '.nav-link, .dropdown-item, .mobile-nav-link--plain, .mobile-submenu-link'
  );

  allLinks.forEach(link => {
    const href = link.getAttribute('href');
    if (!href || href === '#' || href.startsWith('#')) return;

    try {
      const linkPath = new URL(href, window.location.href).pathname;

      // Exact match or index.html match
      const isActive =
        linkPath === currentPath ||
        (currentPath.endsWith('/') && linkPath === currentPath + 'index.html') ||
        (linkPath.endsWith('/index.html') && linkPath.replace('/index.html', '/') === currentPath);

      if (isActive) {
        link.classList.add('active');

        // Mark parent nav-item for desktop dropdown
        const parentNavItem = link.closest('.nav-item');
        if (parentNavItem) {
          const parentLink = parentNavItem.querySelector(':scope > .nav-link');
          if (parentLink) parentLink.classList.add('active');
        }

        // Mark parent mobile accordion button
        const parentAccordion = link.closest('.mobile-submenu');
        if (parentAccordion) {
          const accordionBtn = parentAccordion.previousElementSibling;
          if (accordionBtn) accordionBtn.classList.add('active');
        }
      }
    } catch {
      // Invalid URL — skip
    }
  });
}

/* ─────────────────────────────────────────────
   5. STICKY HEADER OFFSET HELPER
   Adds .page-offset class to <main> if missing,
   accounting for navbar height.
   ───────────────────────────────────────────── */

function initPageOffset() {
  const main   = document.querySelector('main');
  const navbar = document.querySelector('.navbar');
  if (!main || !navbar) return;

  // Use CSS variable approach for accuracy
  const updateOffset = () => {
    const h = navbar.offsetHeight;
    document.documentElement.style.setProperty('--navbar-height', h + 'px');
    // Also directly pad the main element if it has page-offset class
    if (main.classList.contains('page-offset')) {
      main.style.paddingTop = h + 'px';
    }
  };

  updateOffset();

  // Update on resize (e.g. orientation change)
  window.addEventListener('resize', updateOffset, { passive: true });
}

/* ─────────────────────────────────────────────
   6. BOOK NOW BUTTON WIRING
   (In case global.js hasn't loaded yet at
   component injection time, we re-wire here.)
   ───────────────────────────────────────────── */

function initBookNowButtons() {
  document.querySelectorAll('[data-book-now]').forEach(btn => {
    // Remove old listeners to prevent duplicates
    const newBtn = btn.cloneNode(true);
    btn.parentNode.replaceChild(newBtn, btn);

    newBtn.addEventListener('click', (e) => {
      e.preventDefault();
      // Use global PawSpa API if available
      if (window.PawSpa && window.PawSpa.openModal) {
        window.PawSpa.openModal('booking-modal');
      } else {
        // Fallback: scroll to contact
        const contact = document.getElementById('contact-form') ||
                        document.querySelector('.contact-section');
        if (contact) {
          contact.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }
    });
  });
}

/* ─────────────────────────────────────────────
   7. ENTRY POINT
   Called by global.js initNavbar() after the
   navbar HTML is injected.
   ───────────────────────────────────────────── */

function initNavbarComponent() {
  initNavbarScroll();
  initDropdownHover();
  initMobileMenu();
  highlightActiveNavLink();
  initPageOffset();

  // Small delay for Book Now wiring to ensure
  // booking modal is in DOM (from global.js)
  setTimeout(initBookNowButtons, 50);
}

/* ─────────────────────────────────────────────
   8. EXPORT / ATTACH
   Make initNavbarComponent available for
   global.js to call after component injection.
   ───────────────────────────────────────────── */

// Attach to window so global.js can call it
window.initNavbarComponent = initNavbarComponent;

// Also auto-run if the navbar is already in the DOM
// (e.g., when navbar.js is loaded directly on a page)
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.navbar')) {
      initNavbarComponent();
    }
  });
} else {
  if (document.querySelector('.navbar')) {
    initNavbarComponent();
  }
}
